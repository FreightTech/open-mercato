import { expect, type APIRequestContext } from '@playwright/test';
import { apiRequest } from './api';

type ProductFixtureInput = {
  title: string;
  sku: string;
};

type VariantFixtureInput = {
  productId: string;
  name: string;
  sku: string;
  isDefault?: boolean;
};

export async function createProductFixture(
  request: APIRequestContext,
  token: string,
  input: ProductFixtureInput,
): Promise<string> {
  const response = await apiRequest(request, 'POST', '/api/catalog/products', {
    token,
    data: {
      title: input.title,
      sku: input.sku,
      description:
        'Long enough description for SEO checks in QA automation flows. This text keeps the create validation satisfied.',
    },
  });
  expect(response.ok(), `Failed to create product fixture: ${response.status()}`).toBeTruthy();
  const body = (await response.json()) as { id?: string };
  expect(typeof body.id === 'string' && body.id.length > 0).toBeTruthy();
  return body.id as string;
}

export async function createVariantFixture(
  request: APIRequestContext,
  token: string,
  input: VariantFixtureInput,
): Promise<string> {
  const response = await apiRequest(request, 'POST', '/api/catalog/variants', {
    token,
    data: {
      productId: input.productId,
      name: input.name,
      sku: input.sku,
      isDefault: input.isDefault ?? false,
      isActive: true,
    },
  });
  expect(response.ok(), `Failed to create variant fixture: ${response.status()}`).toBeTruthy();
  const body = (await response.json()) as { id?: string };
  expect(typeof body.id === 'string' && body.id.length > 0).toBeTruthy();
  return body.id as string;
}

type CategoryFixtureInput = {
  name: string;
};

export async function createCategoryFixture(
  request: APIRequestContext,
  token: string,
  input: CategoryFixtureInput,
): Promise<string> {
  const response = await apiRequest(request, 'POST', '/api/catalog/categories', {
    token,
    data: { name: input.name },
  });
  expect(response.ok(), `Failed to create category fixture: ${response.status()}`).toBeTruthy();
  const body = (await response.json()) as { id?: string };
  expect(typeof body.id === 'string' && body.id.length > 0).toBeTruthy();
  return body.id as string;
}

export async function deleteCatalogCategoryIfExists(
  request: APIRequestContext,
  token: string | null,
  categoryId: string | null,
): Promise<void> {
  if (!token || !categoryId) return;
  try {
    await apiRequest(request, 'DELETE', `/api/catalog/categories?id=${encodeURIComponent(categoryId)}`, { token });
  } catch {
    return;
  }
}

export async function deleteCatalogProductIfExists(
  request: APIRequestContext,
  token: string | null,
  productId: string | null,
): Promise<void> {
  if (!token || !productId) return;
  try {
    await apiRequest(request, 'DELETE', `/api/catalog/products?id=${encodeURIComponent(productId)}`, { token });
  } catch {
    return;
  }
}
