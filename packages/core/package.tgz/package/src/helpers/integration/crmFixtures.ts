import { expect, type APIRequestContext } from '@playwright/test';
import { apiRequest } from './api';
import { readJsonSafe } from './generalFixtures';

type JsonRecord = Record<string, unknown>;

export { readJsonSafe } from './generalFixtures';

function isRecord(value: unknown): value is JsonRecord {
  return typeof value === 'object' && value !== null;
}

function findStringByKeys(value: unknown, keys: readonly string[]): string | null {
  if (!isRecord(value)) return null;

  for (const key of keys) {
    const candidate = value[key];
    if (typeof candidate === 'string' && candidate.trim().length > 0) {
      return candidate.trim();
    }
  }

  for (const nested of Object.values(value)) {
    if (Array.isArray(nested)) continue;
    const found = findStringByKeys(nested, keys);
    if (found) return found;
  }

  return null;
}

async function createEntity(
  request: APIRequestContext,
  token: string,
  path: string,
  data: Record<string, unknown>,
  idKeys: readonly string[],
): Promise<string> {
  const response = await apiRequest(request, 'POST', path, { token, data });
  const payload = await readJsonSafe(response);
  expect(response.ok(), `Failed POST ${path}: ${response.status()}`).toBeTruthy();
  const id = findStringByKeys(payload, idKeys);
  expect(id, `No id in ${path} response`).toBeTruthy();
  return id as string;
}

export async function createCompanyFixture(
  request: APIRequestContext,
  token: string,
  displayName: string,
): Promise<string> {
  return createEntity(request, token, '/api/customers/companies', { displayName }, ['id', 'entityId', 'companyId']);
}

export async function createPersonFixture(
  request: APIRequestContext,
  token: string,
  input: { firstName: string; lastName: string; displayName: string; companyEntityId?: string },
): Promise<string> {
  const data: Record<string, unknown> = {
    firstName: input.firstName,
    lastName: input.lastName,
    displayName: input.displayName,
  };
  if (input.companyEntityId) {
    data.companyEntityId = input.companyEntityId;
  }
  return createEntity(request, token, '/api/customers/people', data, ['id', 'entityId', 'personId']);
}

export async function createDealFixture(
  request: APIRequestContext,
  token: string,
  input: { title: string; companyIds?: string[]; personIds?: string[]; pipelineId?: string; pipelineStageId?: string; valueAmount?: number; valueCurrency?: string },
): Promise<string> {
  const data: Record<string, unknown> = { title: input.title };
  if (input.companyIds?.length) data.companyIds = input.companyIds;
  if (input.personIds?.length) data.personIds = input.personIds;
  if (input.pipelineId) data.pipelineId = input.pipelineId;
  if (input.pipelineStageId) data.pipelineStageId = input.pipelineStageId;
  if (input.valueAmount !== undefined) data.valueAmount = input.valueAmount;
  if (input.valueCurrency) data.valueCurrency = input.valueCurrency;
  return createEntity(request, token, '/api/customers/deals', data, ['dealId', 'id', 'entityId']);
}

export async function createPipelineFixture(
  request: APIRequestContext,
  token: string,
  input: { name: string; isDefault?: boolean },
): Promise<string> {
  const data: Record<string, unknown> = { name: input.name };
  if (input.isDefault !== undefined) data.isDefault = input.isDefault;
  return createEntity(request, token, '/api/customers/pipelines', data, ['id', 'pipelineId']);
}

export async function createPipelineStageFixture(
  request: APIRequestContext,
  token: string,
  input: { pipelineId: string; label: string; order?: number },
): Promise<string> {
  const data: Record<string, unknown> = { pipelineId: input.pipelineId, label: input.label };
  if (input.order !== undefined) data.order = input.order;
  return createEntity(request, token, '/api/customers/pipeline-stages', data, ['id', 'stageId']);
}

export async function deleteEntityByBody(
  request: APIRequestContext,
  token: string | null,
  path: string,
  id: string | null,
): Promise<void> {
  if (!token || !id) return;
  try {
    await apiRequest(request, 'DELETE', path, { token, data: { id } });
  } catch {
    return;
  }
}

export async function deleteEntityIfExists(
  request: APIRequestContext,
  token: string | null,
  path: string,
  id: string | null,
): Promise<void> {
  if (!token || !id) return;
  try {
    await apiRequest(request, 'DELETE', `${path}?id=${encodeURIComponent(id)}`, { token });
  } catch {
    return;
  }
}
