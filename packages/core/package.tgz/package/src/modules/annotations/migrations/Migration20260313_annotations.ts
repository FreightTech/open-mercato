import { Migration } from '@mikro-orm/migrations';

export class Migration20260313_annotations extends Migration {

  override async up(): Promise<void> {
    // cell_annotations
    this.addSql(`create table if not exists "cell_annotations" ("id" uuid not null default gen_random_uuid(), "organization_id" uuid not null, "tenant_id" uuid not null, "table_id" text not null, "row_id" text not null, "column_key" text not null, "color" text null, "created_at" timestamptz not null, "updated_at" timestamptz not null, "deleted_at" timestamptz null, constraint "cell_annotations_pkey" primary key ("id"));`);
    this.addSql(`create index if not exists "cell_annotations_org_tenant_idx" on "cell_annotations" ("organization_id", "tenant_id");`);
    this.addSql(`create index if not exists "cell_annotations_table_row_idx" on "cell_annotations" ("organization_id", "tenant_id", "table_id", "row_id");`);
    this.addSql(`do $$ begin alter table "cell_annotations" add constraint "cell_annotations_unique_cell" unique ("organization_id", "tenant_id", "table_id", "row_id", "column_key"); exception when others then null; end $$;`);

    // cell_comments
    this.addSql(`create table if not exists "cell_comments" ("id" uuid not null default gen_random_uuid(), "organization_id" uuid not null, "tenant_id" uuid not null, "user_id" uuid not null, "content" text not null, "created_at" timestamptz not null, "updated_at" timestamptz not null, "deleted_at" timestamptz null, "annotation_id" uuid not null, constraint "cell_comments_pkey" primary key ("id"));`);
    this.addSql(`create index if not exists "cell_comments_annotation_created_idx" on "cell_comments" ("annotation_id", "created_at");`);
    this.addSql(`create index if not exists "cell_comments_annotation_idx" on "cell_comments" ("annotation_id");`);

    // cell_annotation_assignees
    this.addSql(`create table if not exists "cell_annotation_assignees" ("id" uuid not null default gen_random_uuid(), "organization_id" uuid not null, "tenant_id" uuid not null, "user_id" uuid not null, "assigned_by" uuid not null, "created_at" timestamptz not null, "annotation_id" uuid not null, constraint "cell_annotation_assignees_pkey" primary key ("id"));`);
    this.addSql(`create index if not exists "cell_annotation_assignees_annotation_id_index" on "cell_annotation_assignees" ("annotation_id");`);
    this.addSql(`do $$ begin alter table "cell_annotation_assignees" add constraint "cell_annotation_assignees_annotation_id_user_id_unique" unique ("annotation_id", "user_id"); exception when others then null; end $$;`);

    // foreign keys (idempotent)
    this.addSql(`do $$ begin alter table "cell_comments" add constraint "cell_comments_annotation_id_foreign" foreign key ("annotation_id") references "cell_annotations" ("id") on update cascade; exception when others then null; end $$;`);
    this.addSql(`do $$ begin alter table "cell_annotation_assignees" add constraint "cell_annotation_assignees_annotation_id_foreign" foreign key ("annotation_id") references "cell_annotations" ("id") on update cascade; exception when others then null; end $$;`);
  }

  override async down(): Promise<void> {
    this.addSql(`drop table if exists "cell_annotation_assignees" cascade;`);
    this.addSql(`drop table if exists "cell_comments" cascade;`);
    this.addSql(`drop table if exists "cell_annotations" cascade;`);
  }

}
