export const id = 'id'
export const created_at = 'created_at'
export const deal = 'deal'
export const company = 'company'
